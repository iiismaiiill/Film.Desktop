package com.myWebServices.havadurumu.dto;

 


public class ViewDetailDTO   {
    public int id;
    public String adi;
    public int yayınTarihi;
    public String tur;
    public String resim;
    public String ulke;
    public String aciklama;
    public String imdbPuan;
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public int getYayınTarihi() {
        return yayınTarihi;
    }

    public void setYayınTarihi(int yayınTarihi) {
        this.yayınTarihi = yayınTarihi;
    }

    public String getTur() {
        return tur;
    }

    public void setTur(String tur) {
        this.tur = tur;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public String getUlke() {
        return ulke;
    }

    public void setUlke(String ulke) {
        this.ulke = ulke;
    }

    public String getAciklama() {
        return aciklama;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }

    public String getImdbPuan() {
        return imdbPuan;
    }

    public void setImdbPuan(String imdbPuan) {
        this.imdbPuan = imdbPuan;
    }

     

     
    
    
}
